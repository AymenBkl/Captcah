from detect import *

base_string = b''
mm = Captcha_detection(base_string)
# mm = Captcha_detection("special.png")
print("the captcha is: ", mm)
